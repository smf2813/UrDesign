import ImageUploadSearch from "./components/ImageUploadSearch"
import FurnitureSpotter from "./components/FurnitureSpotter"
import SimilarFurniture from "./components/SimilarFurniture"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50">
      <main className="container mx-auto px-4 py-12">
        <h1 className="text-5xl font-extrabold text-center text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600 mb-12">
          Furniture Finder
        </h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <ImageUploadSearch />
            <FurnitureSpotter />
          </div>
          <SimilarFurniture />
        </div>
      </main>
    </div>
  )
}

