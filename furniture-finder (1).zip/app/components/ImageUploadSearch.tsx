"use client"

import { useState } from "react"
import { Upload, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ImageUploadSearch() {
  const [image, setImage] = useState<string | null>(null)
  const [search, setSearch] = useState("")

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would integrate with the Pinterest API
    console.log("Searching for:", search)
  }

  return (
    <div className="bg-white/30 backdrop-blur-lg p-8 rounded-2xl shadow-lg transition-all duration-300 hover:shadow-xl">
      <Tabs defaultValue="upload" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 rounded-xl bg-indigo-100/50">
          <TabsTrigger value="upload" className="rounded-xl data-[state=active]:bg-white">
            Upload Image
          </TabsTrigger>
          <TabsTrigger value="search" className="rounded-xl data-[state=active]:bg-white">
            Search Pinterest
          </TabsTrigger>
        </TabsList>
        <TabsContent value="upload">
          <div className="flex flex-col items-center">
            <label htmlFor="image-upload" className="cursor-pointer group">
              <div className="w-full h-64 border-2 border-dashed border-indigo-300 rounded-xl flex items-center justify-center overflow-hidden transition-all duration-300 group-hover:border-indigo-500">
                {image ? (
                  <img
                    src={image || "/placeholder.svg"}
                    alt="Uploaded"
                    className="max-w-full max-h-full object-contain"
                  />
                ) : (
                  <Upload className="w-16 h-16 text-indigo-300 transition-all duration-300 group-hover:text-indigo-500 group-hover:scale-110" />
                )}
              </div>
            </label>
            <input id="image-upload" type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
            <Button className="mt-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
              {image ? "Change Image" : "Upload Image"}
            </Button>
          </div>
        </TabsContent>
        <TabsContent value="search">
          <form onSubmit={handleSearch} className="flex gap-2">
            <Input
              type="text"
              placeholder="Search Pinterest..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-grow"
            />
            <Button type="submit" className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
          </form>
        </TabsContent>
      </Tabs>
    </div>
  )
}

