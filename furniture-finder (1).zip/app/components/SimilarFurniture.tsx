"use client"

import { useState } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { motion } from "framer-motion"

interface FurnitureItem {
  id: number
  name: string
  image: string
  price: number
}

export default function SimilarFurniture() {
  const [similarFurniture, setSimilarFurniture] = useState<FurnitureItem[]>([
    { id: 1, name: "Modern Sofa", image: "/placeholder.svg", price: 999 },
    { id: 2, name: "Leather Armchair", image: "/placeholder.svg", price: 599 },
    { id: 3, name: "Wooden Coffee Table", image: "/placeholder.svg", price: 299 },
    { id: 4, name: "Floor Lamp", image: "/placeholder.svg", price: 129 },
    { id: 5, name: "Bookshelf", image: "/placeholder.svg", price: 449 },
  ])

  return (
    <div className="bg-white/30 backdrop-blur-lg p-8 rounded-2xl shadow-lg transition-all duration-300 hover:shadow-xl">
      <h2 className="text-2xl font-bold mb-6 text-indigo-800">Similar Furniture</h2>
      <div className="space-y-4">
        {similarFurniture.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="overflow-hidden transition-all duration-300 hover:shadow-md">
              <CardContent className="p-0">
                <div className="flex items-center">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    width={100}
                    height={100}
                    className="w-24 h-24 object-cover"
                  />
                  <div className="p-4 flex-grow">
                    <h3 className="font-medium text-indigo-800">{item.name}</h3>
                    <p className="text-indigo-600 font-semibold">${item.price}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

