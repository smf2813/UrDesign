"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"

export default function FurnitureSpotter() {
  const [spottedFurniture, setSpottedFurniture] = useState<string[]>([])

  const handleSpotFurniture = () => {
    // This is where you'd integrate with your furniture spotting AI
    // For now, we'll just simulate it with some dummy data
    setSpottedFurniture(["Sofa", "Coffee Table", "Lamp", "Bookshelf", "Armchair"])
  }

  return (
    <div className="mt-8 bg-white/30 backdrop-blur-lg p-8 rounded-2xl shadow-lg transition-all duration-300 hover:shadow-xl">
      <h2 className="text-2xl font-bold mb-4 text-indigo-800">Spot Furniture</h2>
      <Button onClick={handleSpotFurniture} className="mb-6 bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        Spot Furniture in Image
      </Button>
      {spottedFurniture.length > 0 && (
        <div>
          <h3 className="text-lg font-medium mb-3 text-indigo-700">Spotted Furniture:</h3>
          <ul className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {spottedFurniture.map((item, index) => (
              <motion.li
                key={index}
                className="bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-800 px-4 py-2 rounded-xl text-sm font-medium shadow-sm"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                {item}
              </motion.li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

